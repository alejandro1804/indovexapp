import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/repuesto.dart';

class RepuestoService {
  final _supabase = Supabase.instance.client;

  Future<List<Repuesto>> obtenerRepuestos() async {
    final data = await _supabase
        .from('repuestos')
        .select()
        .eq('activo', true)
        .order('descripcion');
    return (data as List).map((e) => Repuesto.fromMap(e)).toList();
  }

  Future<List<Repuesto>> obtenerRepuestosBajoStock() async {
    final data = await _supabase
        .from('repuestos')
        .select()
        .eq('activo', true)
        .filter('stock_actual', 'lte', 'stock_minimo');
    return (data as List).map((e) => Repuesto.fromMap(e)).toList();
  }

  Future<void> registrarIngreso({
    required String repuestoId,
    required int cantidad,
    String? proveedorId,
    String? descripcion,
  }) async {
    await _supabase.from('ingreso_repuestos').insert({
      'repuesto_id': repuestoId,
      'cantidad': cantidad,
      'proveedor_id': proveedorId,
      'descripcion': descripcion,
      'fecha': DateTime.now().toIso8601String().split('T')[0],
    });
    final repuesto = await _supabase.from('repuestos').select('stock_actual').eq('id', repuestoId).single();
    await _supabase.from('repuestos').update({
      'stock_actual': repuesto['stock_actual'] + cantidad,
    }).eq('id', repuestoId);
  }

  Future<void> registrarSalida({
    required String repuestoId,
    required int cantidad,
    String? ticketId,
    String? observacion,
  }) async {
    await _supabase.from('salida_repuestos').insert({
      'repuesto_id': repuestoId,
      'cantidad': cantidad,
      'ticket_id': ticketId,
      'observacion': observacion,
      'fecha': DateTime.now().toIso8601String().split('T')[0],
    });
    final repuesto = await _supabase.from('repuestos').select('stock_actual').eq('id', repuestoId).single();
    await _supabase.from('repuestos').update({
      'stock_actual': repuesto['stock_actual'] - cantidad,
    }).eq('id', repuestoId);
  }
}
