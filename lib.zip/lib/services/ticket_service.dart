import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/ticket.dart';

class TicketService {
  final _supabase = Supabase.instance.client;

  Future<List<Ticket>> obtenerTickets() async {
    final data = await _supabase
        .from('tickets')
        .select()
        .order('created_at', ascending: false);
    return (data as List).map((e) => Ticket.fromMap(e)).toList();
  }

  Future<List<Ticket>> obtenerTicketsPorEstado(String estado) async {
    final data = await _supabase
        .from('tickets')
        .select()
        .eq('estado', estado)
        .order('created_at', ascending: false);
    return (data as List).map((e) => Ticket.fromMap(e)).toList();
  }

  Future<void> crearTicket({
    required String maquinaId,
    required String descripcion,
    String? fotoUrl,
  }) async {
    final numero = 'TK-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}';
    await _supabase.from('tickets').insert({
      'maquina_id': maquinaId,
      'descripcion_desperfecto': descripcion,
      'numero': numero,
      'estado': 'abierto',
      'foto_url': fotoUrl,
    });
  }

  Future<void> actualizarEstado(String ticketId, String nuevoEstado, String usuarioId, {String? comentario}) async {
    final ticket = await _supabase.from('tickets').select('estado').eq('id', ticketId).single();
    await _supabase.from('tickets').update({'estado': nuevoEstado}).eq('id', ticketId);
    await _supabase.from('ticket_historial').insert({
      'ticket_id': ticketId,
      'usuario_id': usuarioId,
      'estado_anterior': ticket['estado'],
      'estado_nuevo': nuevoEstado,
      'comentario': comentario,
    });
  }

  Future<void> asignarTecnico(String ticketId, String tecnicoId, String usuarioId) async {
    await _supabase.from('tickets').update({
      'tecnico_id': tecnicoId,
      'estado': 'asignado',
    }).eq('id', ticketId);
    await _supabase.from('ticket_historial').insert({
      'ticket_id': ticketId,
      'usuario_id': usuarioId,
      'estado_anterior': 'abierto',
      'estado_nuevo': 'asignado',
      'comentario': 'Técnico asignado',
    });
  }
}
