import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../models/repuesto.dart';
import '../../models/proveedor.dart';
import '../../providers/auth_provider.dart';

class IngresoRepuestoScreen extends StatefulWidget {
  final Repuesto repuesto;

  const IngresoRepuestoScreen({super.key, required this.repuesto});

  @override
  State<IngresoRepuestoScreen> createState() => _IngresoRepuestoScreenState();
}

class _IngresoRepuestoScreenState extends State<IngresoRepuestoScreen> {
  final _supabase = Supabase.instance.client;
  final _cantidadController = TextEditingController(text: '1');
  final _quienEntregaController = TextEditingController();
  final _descripcionController = TextEditingController();
  List<Proveedor> _proveedores = [];
  String? _proveedorSeleccionado;
  bool _cargando = false;

  @override
  void initState() {
    super.initState();
    _cargarProveedores();
  }

  Future<void> _cargarProveedores() async {
    final data = await _supabase.from('proveedores').select().eq('activo', true).order('nombre');
    setState(() {
      _proveedores = (data as List).map((e) => Proveedor.fromMap(e)).toList();
    });
  }

  Future<void> _registrarIngreso() async {
    final cantidad = int.tryParse(_cantidadController.text) ?? 0;
    if (cantidad <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('La cantidad debe ser mayor a 0'), backgroundColor: Colors.red),
      );
      return;
    }

    setState(() => _cargando = true);
    try {
      final usuario = context.read<AuthProvider>().usuario;
      await _supabase.from('ingreso_repuestos').insert({
        'repuesto_id': widget.repuesto.id,
        'proveedor_id': _proveedorSeleccionado,
        'registrado_por': usuario?.id,
        'cantidad': cantidad,
        'quien_entrega': _quienEntregaController.text.trim().isEmpty ? null : _quienEntregaController.text.trim(),
        'descripcion': _descripcionController.text.trim().isEmpty ? null : _descripcionController.text.trim(),
        'fecha': DateTime.now().toIso8601String().split('T')[0],
      });

      // Actualizar stock
      await _supabase.from('repuestos').update({
        'stock_actual': widget.repuesto.stockActual + cantidad,
      }).eq('id', widget.repuesto.id);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Ingreso registrado correctamente'), backgroundColor: Colors.green),
      );
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error al registrar ingreso: $e'), backgroundColor: Colors.red),
      );
    } finally {
      setState(() => _cargando = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ingreso de Repuesto'),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Info repuesto
          Card(
            elevation: 1,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const Icon(Icons.inventory_2_outlined, color: Color(0xFF1F4E79)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(widget.repuesto.descripcion, style: const TextStyle(fontWeight: FontWeight.w600)),
                        Text('Código: ${widget.repuesto.codigo}', style: TextStyle(color: Colors.grey[600], fontSize: 13)),
                        Text('Stock actual: ${widget.repuesto.stockActual} ${widget.repuesto.unidadMedida}',
                            style: const TextStyle(color: Color(0xFF1F4E79), fontWeight: FontWeight.w500)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          // Formulario
          TextField(
            controller: _cantidadController,
            decoration: InputDecoration(
              labelText: 'Cantidad *',
              border: const OutlineInputBorder(),
              suffixText: widget.repuesto.unidadMedida,
            ),
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String?>(
            value: _proveedorSeleccionado,
            decoration: const InputDecoration(
              labelText: 'Proveedor (opcional)',
              border: OutlineInputBorder(),
            ),
            items: [
              const DropdownMenuItem(value: null, child: Text('Sin proveedor')),
              ..._proveedores.map((p) => DropdownMenuItem(value: p.id, child: Text(p.nombre))),
            ],
            onChanged: (v) => setState(() => _proveedorSeleccionado = v),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _quienEntregaController,
            decoration: const InputDecoration(
              labelText: 'Quién entrega (opcional)',
              border: OutlineInputBorder(),
              hintText: 'Nombre de la persona que trae el repuesto',
            ),
            textCapitalization: TextCapitalization.words,
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _descripcionController,
            decoration: const InputDecoration(
              labelText: 'Observaciones (opcional)',
              border: OutlineInputBorder(),
            ),
            maxLines: 2,
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton.icon(
              onPressed: _cargando ? null : _registrarIngreso,
              icon: _cargando
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : const Icon(Icons.add_circle_outline),
              label: const Text('Registrar Ingreso', style: TextStyle(fontSize: 16)),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
