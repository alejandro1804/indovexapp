import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../models/repuesto.dart';
import '../../providers/auth_provider.dart';

class SalidaRepuestoScreen extends StatefulWidget {
  final Repuesto repuesto;

  const SalidaRepuestoScreen({super.key, required this.repuesto});

  @override
  State<SalidaRepuestoScreen> createState() => _SalidaRepuestoScreenState();
}

class _SalidaRepuestoScreenState extends State<SalidaRepuestoScreen> {
  final _supabase = Supabase.instance.client;
  final _cantidadController = TextEditingController(text: '1');
  final _quienRetiraController = TextEditingController();
  final _observacionController = TextEditingController();
  bool _cargando = false;

  Future<void> _registrarSalida() async {
    final cantidad = int.tryParse(_cantidadController.text) ?? 0;
    if (cantidad <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('La cantidad debe ser mayor a 0'), backgroundColor: Colors.red),
      );
      return;
    }

    if (cantidad > widget.repuesto.stockActual) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No hay suficiente stock disponible'), backgroundColor: Colors.red),
      );
      return;
    }

    setState(() => _cargando = true);
    try {
      final usuario = context.read<AuthProvider>().usuario;
      await _supabase.from('salida_repuestos').insert({
        'repuesto_id': widget.repuesto.id,
        'registrado_por': usuario?.id,
        'cantidad': cantidad,
        'quien_retira': _quienRetiraController.text.trim().isEmpty ? null : _quienRetiraController.text.trim(),
        'observacion': _observacionController.text.trim().isEmpty ? null : _observacionController.text.trim(),
        'fecha': DateTime.now().toIso8601String().split('T')[0],
      });

      // Actualizar stock
      await _supabase.from('repuestos').update({
        'stock_actual': widget.repuesto.stockActual - cantidad,
      }).eq('id', widget.repuesto.id);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Salida registrada correctamente'), backgroundColor: Colors.green),
      );
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error al registrar salida: $e'), backgroundColor: Colors.red),
      );
    } finally {
      setState(() => _cargando = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Salida de Repuesto'),
        backgroundColor: Colors.red[700],
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Info repuesto
          Card(
            elevation: 1,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const Icon(Icons.inventory_2_outlined, color: Color(0xFF1F4E79)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(widget.repuesto.descripcion, style: const TextStyle(fontWeight: FontWeight.w600)),
                        Text('Código: ${widget.repuesto.codigo}', style: TextStyle(color: Colors.grey[600], fontSize: 13)),
                        Text(
                          'Stock disponible: ${widget.repuesto.stockActual} ${widget.repuesto.unidadMedida}',
                          style: TextStyle(
                            color: widget.repuesto.stockBajo ? Colors.orange : const Color(0xFF1F4E79),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _cantidadController,
            decoration: InputDecoration(
              labelText: 'Cantidad *',
              border: const OutlineInputBorder(),
              suffixText: widget.repuesto.unidadMedida,
            ),
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _quienRetiraController,
            decoration: const InputDecoration(
              labelText: 'Quién retira (opcional)',
              border: OutlineInputBorder(),
              hintText: 'Nombre de quien retira el repuesto',
            ),
            textCapitalization: TextCapitalization.words,
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _observacionController,
            decoration: const InputDecoration(
              labelText: 'Observaciones (opcional)',
              border: OutlineInputBorder(),
              hintText: 'Para qué se usa, en qué máquina, etc.',
            ),
            maxLines: 2,
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton.icon(
              onPressed: _cargando ? null : _registrarSalida,
              icon: _cargando
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : const Icon(Icons.remove_circle_outline),
              label: const Text('Registrar Salida', style: TextStyle(fontSize: 16)),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red[700],
                foregroundColor: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
